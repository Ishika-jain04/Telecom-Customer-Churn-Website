
  # Telecom Customer Churn Website

  This is a code bundle for Telecom Customer Churn Website. The original project is available at https://www.figma.com/design/6673yhgeobmXhbqLvJ83ix/Telecom-Customer-Churn-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  